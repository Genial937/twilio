@role('Client')
<a href="#!" class="btn btn-primary lift">
  Balance: Kes: 909
</a>
@endrole