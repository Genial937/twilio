

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Overview
                        </h6>

                        

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <a href="<?php echo e(route('index')); ?>" class="btn btn-primary lift">
                            Dashboard
                        </a>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->
    <!-- CARDS -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card shadow">
                    <div class="card-header">
                        <h2 class="card-title">Apps</h2>
                       <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                       <a href="#" data-toggle="modal" data-target="#add" class="btn btn-success pull-right">Add App</a>
                       <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <a href="#" data-dismiss="alert" class="close">&times;</a>
                                <p><?php echo e(session('status')); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3">
                                <div class="card-body p-2">
                                    <div class="row align-items-center">
                                        <div class="col-md-4">
                                            <!-- Avatar -->
                                            <a href="<?php echo e(route('show', $app->id)); ?>" class="pt-2">
                                                <h3><?php echo e($app->app_name); ?></h3>
                                            </a>

                                        </div>
                                        <div class="col-md-8 text-right">
                                            <!-- Dropdown -->
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-ellipses dropdown-toggle" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" data-expanded="false">
                                                    <i class="fe fe-more-vertical"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a href="#!" class="dropdown-item">
                                                        Edit
                                                    </a>
                                                    <a href="#!" class="dropdown-item">
                                                        View
                                                    </a>
                                                    <a href="#!" class="dropdown-item">
                                                        Delete
                                                    </a>
                                                </div>
                                            </div>

                                        </div>
                                    </div> <!-- / .row -->
                                </div> <!-- / .card-body -->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('apps.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h2 class="modal-title">Add App</h2>
                        <a href="#" class="close" data-dismiss="modal" aria-label="Close">&times;</a>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="">App Name</label>
                            <input type="text" name="app_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Sender ID</label>
                            <input type="text" name="sender_id" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Client</label>
                            <select name="client_id" id="" class="form-control" required>
                                <option value="" selected disabled>Select</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" data-dismiss="modal" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\twilio\resources\views/apps/index.blade.php ENDPATH**/ ?>