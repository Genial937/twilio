

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        

                        <!-- Title -->
                        <h1 class="header-title">
                            Contacts
                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->

    <!-- CARDS -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 m-auto">
                <div class="card shadow">
                    <div class="card-header">
                        <h2 class="card-title">Contacts</h2>
                        <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-success pull-right">Add Contact</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Tag</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                               <?php ($count = 1); ?>
                               <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->phone); ?></td>
                                <td><?php echo e($contact->tags->tag_name); ?></td>
                                <td>
                                    <a href="#" data-toggle="modal" data-target="#edit<?php echo e($contact->id); ?>" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></a>
                                    <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\twilio\resources\views/contacts/index.blade.php ENDPATH**/ ?>