

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        

                        <!-- Title -->
                        <h1 class="header-title">
                            Users
                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->

    <!-- CARDS -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card shadow">
                    <div class="card-header">
                        <h2 class="card-title">Users</h2>
                       <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                       <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success pull-right">Add User</a>
                       <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                                <th>Team</th>
                                <?php endif; ?>
                                <th>Action</th>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php
                                   $team = App\Models\Client_user::where('user_id', $user->id)->with('client')->first();
                               ?>
                               <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                               <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($team->client->name); ?></td>
                                <td>
                                    <a href="" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></a>
                                    <a href="" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                               <?php endif; ?>
                               <?php if(auth()->check() && auth()->user()->hasRole('Client')): ?>
                               <tr>
                                <td><?php echo e($user->users->name); ?></td>
                                <td><?php echo e($user->users->email); ?></td>
                                <td><?php echo e($user->users->phone); ?></td>
                                
                                <td>
                                    <a href="" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></a>
                                    <a href="" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                               <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\twilio\resources\views/users/index.blade.php ENDPATH**/ ?>