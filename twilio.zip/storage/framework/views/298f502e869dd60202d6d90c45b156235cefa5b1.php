<?php if(auth()->check() && auth()->user()->hasRole('Client')): ?>
<a href="#!" class="btn btn-primary lift">
  Balance: Kes: 909
</a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\twilio\resources\views/layouts/header.blade.php ENDPATH**/ ?>