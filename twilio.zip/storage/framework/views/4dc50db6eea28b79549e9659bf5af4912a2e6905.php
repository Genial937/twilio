

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        

                        <!-- Title -->
                        <h1 class="header-title">
                            Clients
                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->

    <!-- CARDS -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9 m-auto">
                <div class="card shadow">
                    <div class="card-header">
                        <h2 class="card-title">Add Client</h2>
                        <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-success pull-right">Back</a>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <a href="#" data-dismiss="alert" class="close">&times;</a>
                                <p><?php echo e(session('status')); ?></p>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('clients.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                           <div class="row">
                               <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Client Name</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="">Username</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="">Contact Email</label>
                                    <input type="text" name="contact_email" class="form-control" required>
                                </div>
                               </div>
                               <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Contact Phone</label>
                                    <input type="text" name="contact_phone" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="">Sender ID</label>
                                    <input type="text" name="sender_id" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="">Api Key</label>
                                    <input type="text" name="api_key" class="form-control" required>
                                </div>
                               </div>
                           </div>
                            <div class="form-group">
                                <label for="">Service Provider</label>
                                <select name="vendor" id="" class="form-control" required>
                                    <option value="" selected disabled>Select</option>
                                    <option value="AT">Africa's Talking</option>
                                    <option value="Mobi">Mobi Technologies</option>
                                </select>
                            </div>
                            <div class="form-group text-right">
                                <button class="btn btn-success">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\twilio\resources\views/clients/create.blade.php ENDPATH**/ ?>