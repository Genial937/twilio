<div class="alert alert-success">
    <a href="#" data-dismiss="alert" class="close">&times;</a>
    <p>{{ session('status') }}</p>
</div>