 {{-- Spinners --}}
 <div class="spin-container" id="spin">
    <div class="la-ball-spin la-2x my-spin">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
{{-- /Spinners --}}