<div class="alert alert-danger">
    <a href="#" data-dismiss="alert" class="close">&times;</a>
    <p>{{ session('danger') }}</p>
</div>